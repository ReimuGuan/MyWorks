(function(){
    var directive=angular.module("directive",[]);
    directive.directive('autoFocus',function(){
        return{
            scope:true,
            link:function(scope,ele,attr){
                attr.$observe("autoFocus",function(){
                    setTimeout(function () {
                        ele[0].focus();
                    },0)
                })
            }
        }
    });
})();
