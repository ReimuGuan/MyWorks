(function(){
    var service = angular.module("service",[]);
    service.service("service",["$window",function($window){
        var appService = $window.localStorage.list ? angular.fromJson($window.localStorage.list) : [];
        this.getApp = function () {
            return appService;
        };
        this.save = function(){
            $window.localStorage.list = angular.toJson(appService);
        };
        this.add = function(text) {
            appService.push({task:text,finish:false});
        };
        this.remove = function(index){
            appService.splice(index,1);
        };
        this.count = function (){
            var left=0;
            for (var i = 0 ;i<appService.length;i++)
            {
                if(appService[i].finish==false)
                {
                    left++;
                }
            }
            return left;
        };
        this.selectAll = function (state){
            for (var i = 0 ;i<appService.length;i++)
            {
                appService[i].finish=state;
            }
        };
        this.clearCompleted = function (){
            for (var i = 0 ;i<appService.length;i++)
            {
                if (appService[i].finish == true)
                {
                    appService.splice(i,1);
                    i--;
                }
            }
        }
    }])
})();
