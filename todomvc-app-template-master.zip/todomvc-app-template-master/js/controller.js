(function(){
    var controller=angular.module("controller",["service"]);
controller.controller("demo",["$scope","$location","service",function($scope,$location,service){
    $scope.list=service.getApp();
    //����
    $scope.add="";
    $scope.mission=function(event)
    {
        if (event.keyCode == 13 && $scope.add.trim().length>0)
        {
            service.add($scope.add);
            $scope.add=null;
        }
    };
    //ɾ��
    $scope.remove=function(index)
    {
        service.remove(index);
    };
    //�༭
    $scope.editIndex = -1;
    $scope.edit=function(index){
        $scope.editIndex=index;
    };
    $scope.change=function(){
        $scope.editIndex=-1;
    };
    $scope.pressenter=function(event){
        if (event.keyCode == 13)
        {
            $scope.editIndex=-1;
        }
    };

    //����
    $scope.count=function(){
        var left=service.count();
        $scope.all=!left;
        return left;
    };
    //ȫѡ
    $scope.selectAll=function(){
        service.selectAll(!$scope.all)
    };

    //��������
    $scope.clearCompleted=function(){
        service.clearCompleted();
    };

    //ɸѡ
    $scope.location = $location;
    $scope.clickIndex=0;
    $scope.$watch("location.hash()",function(newVal){
        switch (newVal){
            case "/":
                $scope.type={};
                $scope.clickIndex=0;
                break;
            case "/active":
                $scope.type={finish:false};
                $scope.clickIndex=1;
                break;
            case "/completed":
                $scope.clickIndex=2;
                $scope.type={finish:true};
                break;
        }
    });
    $scope.$watch("list",function (newVal) {
        service.save();
    },true)
}])
})();