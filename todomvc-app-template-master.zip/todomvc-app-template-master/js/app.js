(function (window) {
	'use strict';
	var app=angular.module("myApp",["ngRoute","controller","directive"]);
	//app.config(["$routeProvider",function($routeProvider){
	//	$routeProvider
	//		.when("/",{templateUrl:"home.html",controller:"controller"})
	//		.when("/active",{templateUrl:"active.html",controller:"controller"})
	//		.when("/completed",{templateUrl:"completed.html",controller:"controller"})
	//		.otherwise({redirectTo:"/"})
	//}]);

})(window);
